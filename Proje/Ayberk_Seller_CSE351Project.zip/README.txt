Directives:
1) Open the terminal.
2) Go to the correct folder that lex,yacc and MAKEFILE files are in using terminal commands.
3) Type in terminal:
	make (This will use the MAKEFILE file and quickly makes what we need.)
	./termProject INPUTFILE.sh OUTPUTFILE.pl
Note: INPUTFILE.sh can be the name of the file to be converted.
      OUTPUTFILE.pl is the output that is converted to pl language. Name chosen by the user.
4) Now you can see the OUTPUTFILE.pl in the corresponding folder and check if it's converted correctly or not.
5) In order to run the converted pl file, you must type the following in the terminal:
	perl OUTPUTFILE.pl
6) You can see the result in the terminal now.
