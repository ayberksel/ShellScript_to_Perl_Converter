#!/bin/sh
# Hello World Program
i55abc2zsd=5
echo $i55abc2zsd
iss111=$((3+4))
echo $iss111
a=$(($iss111+($i55abc2zsd/5)))
echo $a
